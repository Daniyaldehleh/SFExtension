//
//  ViewController.swift
//  BeTImeful2
//
//  Created by Timothy Head on 24/12/2021.
//

import Cocoa
import SafariServices
import WebKit
import StoreKit
import SwiftyStoreKit
import os.log
import SafariServices.SFSafariApplication
import SafariServices.SFSafariExtensionManager

let extensionBundleIdentifier = "com.timothyhead.BeTImeful2.Extension"

class ViewController: NSViewController, WKNavigationDelegate, WKScriptMessageHandler {

    @IBOutlet weak var restoreButton: NSButton!
    @IBOutlet weak var subscribeButton: NSButton!
    @IBOutlet var webView: WKWebView!

    var productID = "BeTimeful_59.88_1Y_1w0"
    let subscription = RegisteredUser.subcritption
    
    //MARK: use your own bundleID
    var bundleID = "com.timothyhead.BeTImeful2"
    let defaultId = "ok"
    //MARK: Put the shared secret  from App StoreConnect in place of the X's
    var sharedsecret = "XXXXXXXXXXXXX"
    var receiptData  = Data()
    var  receiptString = String()
    var webview: WKWebView!
    let contentController = WKUserContentController()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        SFSafariExtensionManager.getStateOfSafariExtension(withIdentifier: extensionBundleIdentifier) { state, error in
            if error != nil {
                print("An Error has occurred with state of safri extension \(error)")
            }
        }
        
        self.webView.navigationDelegate = self

        self.webView.configuration.userContentController.add(self, name: "controller")

        self.webView.loadFileURL(Bundle.main.url(forResource: "Main", withExtension: "html")!, allowingReadAccessTo: Bundle.main.resourceURL!)
        
        SFSafariExtensionManager.getStateOfSafariExtension(withIdentifier: extensionBundleIdentifier) { (state, error) in
            guard let state = state, error == nil else {
            // Insert code to inform the user that something went wrong.
                return
            }
            self.verifyPurchase(sharedSecret: self.sharedsecret, product: .subcritption)
        }
        receiveMessageFromExtension { alert in
            alert.runModal()
        }
    }
        deinit {
               if let webView = webview{
                   let ucc = webView.configuration.userContentController
                   ucc.removeAllUserScripts()
                   ucc.removeScriptMessageHandler(forName: "subscribe")
                   ucc.removeScriptMessageHandler(forName:  "unsubscribe")
               }
         
        }
    @IBAction func subscribeButtonPressed(_ sender: Any) {
        purchaseAProduct(product: subscription)
        
    }
    @IBAction func restoreButtonPressed(_ sender: Any) {
        self.restorePurchase()
    }
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        SFSafariExtensionManager.getStateOfSafariExtension(withIdentifier: extensionBundleIdentifier) { (state, error) in
            guard let state = state, error == nil else {
                // Insert code to inform the user that something went wrong.
                print("Not switched on")
                return
            }

            DispatchQueue.main.async {
                webView.evaluateJavaScript("show(\(state.isEnabled)")
            }
        }
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        if (message.body as! String != "open-preferences") {
            return;
        }
        guard let dict = message.body as? [String : AnyObject] else {
            return
        }

        print(dict)

        SFSafariApplication.showPreferencesForExtension(withIdentifier: extensionBundleIdentifier) { error in
            DispatchQueue.main.async {
                NSApplication.shared.terminate(nil)
            }
        }
    }

}

V
