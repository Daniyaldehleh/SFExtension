//
//  SwiftyStoreKitFunctions.swift
//  BeTImeful2
//
//  Created by Timothy Head on 24/12/2021.
//

import Foundation
import StoreKit
import SwiftyStoreKit
import AppKit

enum RegisteredUser: String {
    case subcritption  = "BeTimeful_59.88_1Y_1w0"
    
}

extension ViewController {

    
  
    func verifyPurchase(sharedSecret: String, product: RegisteredUser) {
        let appleValidator = AppleReceiptValidator(service: .sandbox, sharedSecret: sharedSecret)
        SwiftyStoreKit.verifyReceipt(using: appleValidator) { result in
            switch result {
            case .success(let receipt):
                let productId = self.productID
                // Verify the purchase of a Subscription
              
                let purchaseResult = SwiftyStoreKit.verifySubscription(
                    ofType: .autoRenewable, // or .nonRenewing (see below)
                    productId: productId,
                    inReceipt: receipt)
                DispatchQueue.main.async {
                    self.alertForverifySubscription(result: purchaseResult).runModal()
                }
             
              
               
               
                
                
                switch purchaseResult {
                case .purchased(let expiryDate, let items):
                    print("\(productId) is valid until \(expiryDate)\n\(items)\n")
                case .expired(let expiryDate, let items):
                    print("\(productId) is expired since \(expiryDate)\n\(items)\n")
                    self.sendMessageToExtention(subscriptionStatus: "Unsubscried")
               
                case .notPurchased:
                    print("The user has never purchased \(productId)")
                }

            case .error(let error):
                print("Receipt verification failed: \(error)")
              
            }
         
        }
    }
    func retriveProductInfo(purchase: RegisteredUser) {
        SwiftyStoreKit.retrieveProductsInfo([self.productID]) { result in
            if let product = result.retrievedProducts.first {
                let priceString = product.localizedPrice!
                print("Product: \(String(describing: product.subscriptionGroupIdentifier)), price: \(priceString)")
            }
            else if let invalidProductId = result.invalidProductIDs.first {
                print("Invalid product identifier: \(invalidProductId)")
            }
            else {
                print("Error: \(String(describing: result.error))")
            }
            DispatchQueue.main.async {
                self.alertForProductRetrivalInfo(result: result).runModal()
            }
        }
    }
    func purchaseAProduct(product: RegisteredUser) {
        SwiftyStoreKit.purchaseProduct(self.productID) { [self] result in
            DispatchQueue.main.async {
                self.alertForPurchaseResult(result: result).runModal()
            }
          
         
            if  case .success(let product) = result {
                self.sendMessageToExtention(subscriptionStatus: "Subscribed")
                if product.needsFinishTransaction {
                    SwiftyStoreKit.finishTransaction(product.transaction)
                  
                  
                  
                }
                
            }
            switch result {
            
              
                            
            case .success(let purchase):
                print("Purchase Success: \(purchase.productId)")
                if purchase.productId == self.productID {
                    // add your product
                    self.sendMessageToExtention(subscriptionStatus: "Subscribed")
                    print("Your product has been built")
                   
                   
                   
                }
            case .error(let error):
                switch error.code {
                case .unknown: print("Unknown error. Please contact support")
                case .clientInvalid: print("Not allowed to make the payment")
                case .paymentCancelled: break
                case .paymentInvalid: print("The purchase identifier was invalid")
                case .paymentNotAllowed: print("The device is not allowed to make the payment")
                case .storeProductNotAvailable: print("The product is not available in the current storefront")
                case .cloudServicePermissionDenied: print("Access to cloud service information is not allowed")
                case .cloudServiceNetworkConnectionFailed: print("Could not connect to the network")
                case .cloudServiceRevoked: print("User has revoked permission to use this cloud service")
                default: print((error as NSError).localizedDescription)
                }
                 
            }
        }
    }
    func restorePurchase() {
        SwiftyStoreKit.restorePurchases(atomically: true) { results in
            if results.restoreFailedPurchases.count > 0 {
                print("Restore Failed: \(results.restoreFailedPurchases)")
            }
            else if results.restoredPurchases.count > 0 {
                print("Restore Success: \(results.restoredPurchases)")
            }
            else {
                print("Nothing to Restore")
            }
            for product in results.restoredPurchases {
                if product.needsFinishTransaction {
                    SwiftyStoreKit.finishTransaction(product.transaction)
                }
            }
            DispatchQueue.main.async {
                self.alertForRestorePurchases(result: results).runModal()
            }
        }
    }
    func retriveLocalReceipt() {
        receiptData = SwiftyStoreKit.localReceiptData ?? Data()
        receiptString = receiptData.base64EncodedString(options: [])
    }
    func fetchReceipt() {
        SwiftyStoreKit.fetchReceipt(forceRefresh: true) { result in
            DispatchQueue.main.async {
                self.alertForRefreshRecipt(result: result).runModal()
            }
            switch result {
            case .success(let receiptData):
                let encryptedReceipt = receiptData.base64EncodedString(options: [])
                print("Fetch receipt success:\n\(encryptedReceipt)")
            case .error(let error):
                print("Fetch receipt failed: \(error)")
            }
        }
    }

    func purchaseIdentifier() {
        let appleValidator = AppleReceiptValidator(service: .sandbox, sharedSecret: sharedsecret)
    SwiftyStoreKit.verifyReceipt(using: appleValidator) { result in
        switch result {
        case .success(let receipt):
            let productIds = SwiftyStoreKit.getDistinctPurchaseIds(inReceipt: ReceiptInfo())
            let emptySet: Set = [""]
            
         
            let purchaseResult = SwiftyStoreKit.verifySubscriptions(productIds: (productIds ?? emptySet)!, inReceipt: receipt)
            switch purchaseResult {
            case .purchased(let expiryDate, let items):
                print("\(String(describing: productIds)) are valid until \(expiryDate)\n\(items)\n")
            case .expired(let expiryDate, let items):
                print("\(String(describing: productIds)) are expired since \(expiryDate)\n\(items)\n")
            case .notPurchased:
                print("The user has never purchased \(String(describing: productIds))")
            }
        case .error(let error):
            print("Receipt verification failed: \(error)")
        }
    }
    }
    
    func verifyReciept() {
        let appleValidator = AppleReceiptValidator(service: .sandbox, sharedSecret: sharedsecret)
        SwiftyStoreKit.verifyReceipt(using: appleValidator, forceRefresh: false) { result in
            DispatchQueue.main.async {
                self.alertForVerifyReciept(result: result).runModal()
            }
            
           
            switch result {
            case .success(let receipt):
                print("Verify receipt success: \(receipt)")
                print(receipt)
            case .error(let error):
                print("Verify receipt failed: \(error)")
                self.fetchReceipt()
            }
           
           
            
        }
    }
   
   

    func alertWithTitle(title: String, message: String) -> NSAlert {
        let alert = NSAlert()
        alert.addButton(withTitle: title)
        alert.alertStyle = .informational
        alert.messageText = message
        alert.informativeText = ""
       return alert
    }
    func alertForProductRetrivalInfo(result: RetrieveResults ) -> NSAlert {
        if let product = result.retrievedProducts.first {
            let mypriceString = product.price.description(withLocale: nil)
            return alertWithTitle(title: "The Subsription period \(product.localizedSubscriptionPeriod)", message: "The price \(mypriceString)")
        } else if let invalidProductId = result.invalidProductIDs.first {
         return alertWithTitle(title: "Could not retrive product info", message: "invalid product Indentifier \(invalidProductId)")
        } else {
            let errorString = result.error?.localizedDescription ?? "unknown error please contact support"
            return alertWithTitle(title: "Could not retrive product info", message: "\(errorString)")
        }
    }
    func alertForPurchaseResult(result: PurchaseResult) -> NSAlert {
        switch result {
        case .success(let product):
            print("purchase successful \(product.productId)")
            return alertWithTitle(title: "Thank you", message: "Purchase Confirmed")
        case .error(let error):
            print("purchase failed \(error)")
           return alertWithTitle(title: "purchase Falied", message: "\(error.localizedDescription)")
        }
    }
    func alertForRestorePurchases(result: RestoreResults) -> NSAlert {
        if result.restoreFailedPurchases.count > 0 {
            print("Restore failed \(result.restoreFailedPurchases)")
            return alertWithTitle(title: "resotre failed", message: "Unknown error please contact support")
            
        } else if result.restoredPurchases.count > 0 {
            return alertWithTitle(title: "purchases restored", message: "Your purchase has been restored")
        } else {
            return alertWithTitle(title: "Nothing to restore", message: "No previuous purchases were made or you're currently subscribed")
        }
    }
    func alertForVerifyReciept(result: VerifyReceiptResult) -> NSAlert {
        switch result {
        case .success(let receipt):
            return alertWithTitle(title: "My reciept is verified", message: "Reciept verified remotely \(receipt)")
        case .error(let error):
            switch error {
            case .noReceiptData:
                return alertWithTitle(title: "Reciept verification", message: "No reciept data found applicationwill try to get a new one try again")
            default:
                return alertWithTitle(title: "Reciept verification", message: "Recipt verification failed")
            }
        }
    }
    func alertForverifySubscription(result: VerifySubscriptionResult) -> NSAlert {
        switch result {
        case  .purchased(let expiryDate, _):
            return alertWithTitle(title: "product is purchased", message: "Product is valid untill \(expiryDate)")
        case .notPurchased:
            return alertWithTitle(title: "Not Purchsed", message: "This product has never been  purchased")
        case .expired(let expiryDate, _):
            return alertWithTitle(title: "product expired", message: "product is expired since \(expiryDate)")
        }
    }
    func alertForVerifyPurchase(result : VerifyPurchaseResult) -> NSAlert {
        switch result {
        case .purchased(let item):
            return alertWithTitle(title: "Product is purchased", message: "product will not expire \(item)")
        case .notPurchased:
            return alertWithTitle(title: "Not purchesed", message: "Product has never been purchaesed")
        }
    }
    func alertForRefreshRecipt(result: FetchReceiptResult) -> NSAlert {
        switch result {
        case .success(let receiptData):
            return alertWithTitle(title: "Reciept resfrehed", message: "Reciept refreshed successfuly \(receiptData)")
        case .error(let error):
            return alertWithTitle(title: "Reciept refresh failed", message: "Reciept refresh failed \(error)")
        }
    }

}
