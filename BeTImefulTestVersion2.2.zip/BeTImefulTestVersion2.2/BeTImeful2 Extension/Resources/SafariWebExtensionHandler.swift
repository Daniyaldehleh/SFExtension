//
//  SafariWebExtensionHandler.swift
//  BeTImeful2 Extension
//
//  Created by Timothy Head on 24/12/2021.
//

import SafariServices
import os.log

let SFExtensionMessageKey = "message"

class SafariWebExtensionHandler: NSObject, NSExtensionRequestHandling {

    func beginRequest(with context: NSExtensionContext) {
    let item = context.inputItems[0] as! NSExtensionItem
    let message = item.userInfo?[SFExtensionMessageKey]
    os_log(.default, "Received message from browser.runtime.sendNativeMessage: %@", message as! CVarArg)

    let defaults = UserDefaults(suiteName: "test.group")
//    let messageDictionary = message as? [String: String]
//    var emptyVariable: String?
//    if messageDictionary?["message"] == "Hello from background page" {
//        emptyVariable = "1"
//        defaults?.set(true, forKey: "askToSubscribe")
//
//    } else {
//        emptyVariable = "2"
//    defaults?.set(false, forKey: "askToSubscribe")
//    }
        defaults?.set(false, forKey: "askToSubscribe")
        defaults?.set(true, forKey: "askToSubscribe")
//    print(("To console"))
    let response = NSExtensionItem()
    response.userInfo = [ SFExtensionMessageKey: [ "Response to": "hello" ] ]

    context.completeRequest(returningItems: [response], completionHandler: nil)
    }

    
}
