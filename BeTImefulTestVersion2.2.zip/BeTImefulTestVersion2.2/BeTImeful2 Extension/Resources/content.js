browser.runtime.sendMessage({ greeting: "hello" }).then((response) => {
    console.log("Received response: ", response);
});

browser.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log("Received request: ", request);
});
browser.runtime.connectNative("com.timothyhead.BeTImeful2");

port.onMessage.addListener(function(message) {
console.log("Received native port message:");
console.log(message);
});
browser.runtime.sendMessage()
browser.runtime.onMessage.addListener()
