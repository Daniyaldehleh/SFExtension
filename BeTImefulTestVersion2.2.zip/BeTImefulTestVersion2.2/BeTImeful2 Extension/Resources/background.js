//browser.runtime.onMessage.addListener((request, sender, sendResponse) => {
//    console.log("Received request: ", request);
//
//    if (request.greeting === "hello")
//        sendResponse({ farewell: "goodbye" });
//});
//
//// Wait for the DOM to load before dispatching a message to the app extension's Swift code.
//document.addEventListener("DOMContentLoaded", function(event) {
//    safari.extension.dispatchMessage("GetWebsiteUrl");
//});
//
//// Listens for messages sent from the app extension's Swift code.
//safari.self.addEventListener("message", messageHandler);
//
//function messageHandler(event) {
//    if(event.name === "WebsiteUrl"){
//        console.log("WebsiteUrl >>>", document.URL)
//        callViewController();
//    }
//}

//receive message from sendMessageToExtention(subscriptionStatus: String) in VCEXtension
//var issubcribed = false;
//browser.runtime.onMessage.addListener((request, sender, sendResponse) => {
//    if (request.type == "Subscribe") {
//        browser.runtime.sendNativeMessage( { message: "Subscribe"});
//
//    }
//});





//browser.runtime.sendNativeMessage("Betimeful.BeTiemfulSafari", {message: "Hello from background page"}, function(response) {
//    console.log("Received sendNativeMessage response:");
//    console.log(response);
//});

//setTimeout(function() {
//
//try{
//    console.log('ran')
//    browser.runtime.sendNativeMessage("Betimeful.BeTiemfulSafari", {message: "Hello from background page"}, function(response) {
//    console.log("Received sendNativeMessage response:");
//    console.log(response);
//})
//;}catch(err){
//    console.log(err)
//}
//}, 10000);
browser.runtime.sendNativeMessage({ message: "Subscribe" });
// Set up a connection to receive messages from the native app.
port = browser.runtime.connectNative("Betimeful.BeTiemfulSafari");
//port.postMessage("Hello from JavaScript Port");
port.onMessage.addListener(function(message) {
    console.log("Received native port message:");
    console.log(message);
    if (message == "Subscribed") {
        issubcribed = true
    } else if (message == "Unsubscried") {
        issubcribed = false
    }
});
port.onDisconnect.addListener(function(disconnectedPort) {
    console.log('Received native port disconnect:');
    console.log(disconnectedPort);
});

browser.runtime.sendNativeMessage("Betimeful.BeTiemfulSafari", {message: "Hello from background page"}, function(response) {
console.log("Received sendNativeMessage response:");
console.log(response);
})
